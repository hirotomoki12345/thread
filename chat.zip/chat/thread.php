<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>スレッド: <?php echo htmlspecialchars($_GET['name']); ?></title>
    <link rel="stylesheet" href="style.css">

    <script>
        window.onload = function() {
            const storedName = localStorage.getItem('username');
            if (storedName) {
                document.getElementById('name').value = storedName;
            }
        };

        function saveName() {
            const name = document.getElementById('name').value;
            localStorage.setItem('username', name);
        }
    </script>
</head>
<body>
    <h1>スレッド: <?php echo htmlspecialchars($_GET['name']); ?></h1>
    <?php
    $thread_dir = 'threads/' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', $_GET['name']);
    if (file_exists("$thread_dir/index.txt")) {
        $comments = file("$thread_dir/index.txt", FILE_IGNORE_NEW_LINES);

        foreach ($comments as $comment) {
            if (preg_match('/\(file_path: (.+)\)$/', $comment, $matches)) {
                $comment_text = preg_replace('/ \(file_path: .+\)$/', '', $comment);
                $file_path = $matches[1];
                echo '<p>' . nl2br(allow_some_html_tags($comment_text)) . '</p>';

                $file_ext = pathinfo($file_path, PATHINFO_EXTENSION);
                if (in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                    echo '<img src="' . htmlspecialchars($file_path) . '" alt="Image" style="max-width: 100%; height: auto;">';
                } elseif (in_array($file_ext, ['mp4', 'avi', 'mkv'])) {
                    echo '<video controls style="max-width: 100%; height: auto;">';
                    echo '<source src="' . htmlspecialchars($file_path) . '" type="video/' . htmlspecialchars($file_ext) . '">';
                    echo 'お使いのブラウザは動画タグに対応していません。';
                    echo '</video>';
                } else {
                    echo '<a href="' . htmlspecialchars($file_path) . '" download>' . htmlspecialchars(basename($file_path)) . '</a>';
                }
            } else {
                echo '<p>' . nl2br(allow_some_html_tags($comment)) . '</p>';
            }
        }
    } else {
        echo '<p>コメントはまだありません。</p>';
    }

    function allow_some_html_tags($string) {
        $allowed_tags = '<b><i><u><strong><em><p><br>';
        return strip_tags($string, $allowed_tags);
    }
    ?>
    <h2>コメントを追加</h2>
    <form action="add_comment.php" method="post" enctype="multipart/form-data" onsubmit="saveName()">
        <input type="hidden" name="thread_name" value="<?php echo htmlspecialchars($_GET['name']); ?>">
        名前: <input type="text" name="name" id="name" required><br>
        コメント: <input type="text" name="comment" required><br>
        ファイル: <input type="file" name="file"><br>
        <button type="submit">送信</button>
    </form>

    <footer><a href="/">HOME</a></footer>
</body>
</html>
