<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>スレッドサイト</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <h1>スレッド一覧</h1>
    <?php
    $threads = scandir('threads');
    foreach ($threads as $thread) {
        if ($thread !== '.' && $thread !== '..') {
            echo '<a href="thread.php?name=' . urlencode($thread) . '">' . htmlspecialchars($thread) . '</a><br>';
        }
    }
    ?>
    <h2>新しいスレッドを作成</h2>
    <form action="create_thread.php" method="post">
        スレッド名: <input type="text" name="thread_name" required><br>
        <button type="submit">作成</button>
    </form>
</body>
</html>
