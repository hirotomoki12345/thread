<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $thread_name = htmlspecialchars($_POST['thread_name']);
    $comment = htmlspecialchars($_POST['comment']);
    $name = htmlspecialchars($_POST['name']);
    $timestamp = date('Y-m-d H:i:s');
    $thread_dir = 'threads/' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', $thread_name);

    $comment_line = "[$timestamp] $name: $comment";

    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = "$thread_dir/uploads/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = basename($_FILES['file']['name']);
        $file_size = $_FILES['file']['size'];
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'avi', 'mkv', 'pdf', 'txt'];

        if (in_array(strtolower($file_ext), $allowed_extensions) && $file_size <= 100 * 1024 * 1024) {
            $random_name = uniqid() . '.' . $file_ext;
            $file_path = $upload_dir . $random_name;
            if (move_uploaded_file($file_tmp, $file_path)) {
                $comment_line .= ' (file_path: ' . htmlspecialchars($file_path) . ')';
            } else {
                $comment_line .= ' [ファイルのアップロードに失敗しました]';
            }
        } else {
            $comment_line .= ' [許可されていないファイル形式またはサイズが大きすぎます]';
        }
    }

    if (!is_dir($thread_dir)) {
        mkdir($thread_dir, 0777, true);
    }

    file_put_contents("$thread_dir/index.txt", $comment_line . PHP_EOL, FILE_APPEND);

    header("Location: thread.php?name=" . urlencode($thread_name));
    exit;
}
?>
