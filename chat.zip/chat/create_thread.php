<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $thread_name = htmlspecialchars($_POST['thread_name']);
    $dir_name = 'threads/' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', $thread_name);

    if (!file_exists($dir_name)) {
        mkdir($dir_name, 0777, true);
        file_put_contents("$dir_name/index.txt", "");
    }

    header("Location: thread.php?name=" . urlencode($dir_name));
    exit;
}
?>
